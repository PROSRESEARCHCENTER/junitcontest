package us.codecraft.webmagic;

import us.codecraft.webmagic.pipeline.Pipeline;

/**
 * @author code4crafter@gmail.com
 */
public class MockPipeline implements Pipeline{
    @Override
    public void process(ResultItems resultItems, Task task) {

    }
}
