export JAVA_OPTS=-Djavax.xml.accessExternalSchema=http
