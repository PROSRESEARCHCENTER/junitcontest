PDP initialization must fail with IllegalArgumentException when using unknown/unsupported Function as Match function
